package ar.edu.uade.banco.cuenta;

import ar.edu.uade.banco.Moneda;
import ar.edu.uade.banco.operacion.Operacion;

public class CajaAhorro extends Cuenta {
    private float tasaInteres;

    protected CajaAhorro(Moneda moneda, float costoMantenimiento, float tasaInteres) {
        super(moneda, costoMantenimiento);
        this.tasaInteres = tasaInteres;
    }

    @Override
    protected String getAbreviatura() {
        return "CA";
    }

    @Override
    public Operacion extraer(float monto) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'extraer'");
    }    
}
