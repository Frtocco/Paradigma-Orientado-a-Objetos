package ar.edu.uade.banco.cuenta;

public enum EstadoCuenta {
    INACTIVA,
    ACTIVA
}
