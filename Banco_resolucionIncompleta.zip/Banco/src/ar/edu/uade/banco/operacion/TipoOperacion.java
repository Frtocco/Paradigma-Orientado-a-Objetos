package ar.edu.uade.banco.operacion;

public enum TipoOperacion {
    EXTRACCION,
    DEPOSITO
}
