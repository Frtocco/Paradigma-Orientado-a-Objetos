package ar.edu.uade.banco.cliente;

public enum EstadoCliente {
    ACTIVO,
    INACTIVO
}
