package ar.edu.uade.banco.exceptions;

public class CuentaInactivaException extends Exception {

    public CuentaInactivaException(String mensaje) {
        super(mensaje);
    }

}
