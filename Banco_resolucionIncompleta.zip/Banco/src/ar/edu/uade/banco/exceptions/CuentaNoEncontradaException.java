package ar.edu.uade.banco.exceptions;

public class CuentaNoEncontradaException extends Exception {

    public CuentaNoEncontradaException(String mensaje) {
        super(mensaje);
    }

}
