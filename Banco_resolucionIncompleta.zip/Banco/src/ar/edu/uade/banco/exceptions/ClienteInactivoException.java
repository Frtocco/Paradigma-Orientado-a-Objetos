package ar.edu.uade.banco.exceptions;

public class ClienteInactivoException extends Exception {
    
    public ClienteInactivoException(String mensaje) {
        super(mensaje);
    }

}
