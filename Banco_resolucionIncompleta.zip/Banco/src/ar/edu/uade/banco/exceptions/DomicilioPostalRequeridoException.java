package ar.edu.uade.banco.cliente;

public class DomicilioPostalRequeridoException extends Exception {

    public DomicilioPostalRequeridoException(String message) {
        super(message);
    }
    
}
