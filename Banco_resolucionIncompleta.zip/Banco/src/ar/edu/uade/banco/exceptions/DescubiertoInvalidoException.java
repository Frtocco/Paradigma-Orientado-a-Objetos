package ar.edu.uade.banco.exceptions;

public class DescubiertoInvalidoException extends Exception {
    public DescubiertoInvalidoException(String mensaje) {
        super(mensaje);
    }

}
